// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;

import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import HomeScreen from "./screens/HomeScreen";
import PublicProfileScreen from "./screens/PublicProfileScreen";
import PersonalProfileScreen from "./screens/PersonalProfileScreen";

function App() {
    return ( <
        div className = "font-nunito h-screen" >
        <
        Navbar / >
        <
        Routes >
        <
        Route path = "/personal-profile"
        element = { < PersonalProfileScreen / > }
        />{" "} <
        Route path = "/public-profile"
        element = { < PublicProfileScreen / > }
        />{" "} <
        Route path = "/"
        element = { < HomeScreen / > }
        />{" "} <
        /Routes>{" "} <
        /div>
    );
}

export default App;