import { useState } from "react";
import Modal from "react-modal";
import Login from "./Login/Login";
import Register from "./Register/Register";
import { useNavigate } from "react-router-dom";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};

const Navbar = () => {
  const [modalCase, setModalCase] = useState("login");
  const [modalIsOpen, setIsOpen] = useState(false);
  const [mobHeight, setMobHeight] = useState('3rem')

  function openModal(type) {
    if (type === "register") {
      setModalCase("register");
      setIsOpen(true);
    } else {
      setModalCase("login");
      setIsOpen(true);
    }
  }

  function closeModal() {
    setIsOpen(false);
  }

  const navigate = useNavigate();

  const openMobNav = () => {
    if(mobHeight === '3rem'){
      setMobHeight('10rem')
    }else{
      setMobHeight('3rem')
    }
  }

  return (
    <div
      className={`sm:flex justify-between items-center sm:px-6 px-2 sm:h-16 bg-white overflow-hidden sm:py-0 py-2 duration-300`}
      style={window.innerWidth > 760 ? { borderBottom: "1px solid #E3E3E3", height: '4rem' } : { borderBottom: "1px solid #E3E3E3", height: mobHeight }}
    >
      <img
        src="/images/menu-icon.png"
        alt=""
        className="absolute top-3 right-2 sm:hidden block"
        onClick={openMobNav}
      />
      <div className="flex items-center" onClick={() => navigate("/")}>
        <img
          src="/images/logo_multidom.png"
          alt="Multidom | Logo"
          className="h-6 mr-3"
        />
        <p className="text-gray-500 text-xl font-bold">Meșteri</p>
      </div>
      <div className="flex items-center sm:flex-row flex-col sm:mt-0 mt-5">
        <button
          className="bg-transparent px-4 py-1 mx-4 font-semibold hover:font-bold sm:w-auto w-full"
          onClick={() => openModal("login")}
        >
          Autentificare
        </button>
        <button
          className="sm:w-auto w-full bg-black px-4 py-2 text-white rounded mx-4 hover:bg-transparent border border-solid border-black hover:text-black duration-300"
          onClick={() => openModal("register")}
        >
          Inregistrare
        </button>
      </div>
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        style={customStyles}
      >
        {modalCase === "register" ? (
          <Register closeModal={closeModal} setModalCase={setModalCase} />
        ) : (
          <Login closeModal={closeModal} setModalCase={setModalCase} />
        )}
      </Modal>
    </div>
  );
};

export default Navbar;
