import { useState } from "react";
import LoginForm from "./LoginSteps/LoginForm";
import NewPassword from "./LoginSteps/NewPassword";
import RecoverPassword from "./LoginSteps/RecoverPassword";

const Login = ({ closeModal, setModalCase }) => {
  const [step, setStep] = useState(0);

  return (
    <>
    {step === 0 ? (
      <LoginForm closeModal={closeModal} setModalCase={setModalCase} setStep={setStep}  />
    ) : step === 1 ? (
      <RecoverPassword closeModal={closeModal} setStep={setStep} />
    ) : step === 2 && (
      <NewPassword closeModal={closeModal} setStep={setStep} />
    )}
    </>
  );
};

export default Login;
