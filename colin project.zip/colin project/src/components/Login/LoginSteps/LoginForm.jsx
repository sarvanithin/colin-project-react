import SimpleInput from "../../Inputs/SimpleInput";
import PrimaryButton from "../../Buttons/PrimaryButton";
import SecondaryButton from "../../Buttons/SecondaryButton";

const LoginForm = ({ closeModal, setModalCase, setStep }) => {
  return (
    <div className="px-20 py-6" style={{ width: "26rem" }}>
      <img
        src="/images/close_icon.png"
        alt="Close Icon"
        className="absolute top-2 right-2 cursor-pointer"
        onClick={closeModal}
      />
      <img src="/images/logo_small.png" alt="Logo" className="mx-auto block" />
      <p className="mt-10 text-2xl font-semibold font-nunitosans">
        Autentificare
      </p>
      <div className="w-full mt-4">
        <SimpleInput inputLabel="Email" />
      </div>
      <div className="w-full mt-4">
        <SimpleInput inputLabel="Parola" />
      </div>
      <PrimaryButton text="Intra in cont" />
      <SecondaryButton text="Recupereaza parola" onClick={() => setStep(1)} />
      <p className="mt-12 text-center">
        Nu ai cont?{" "}
        <span
          className="font-semibold underline cursor-pointer"
          onClick={() => setModalCase("register")}
        >
          Inregistreaza-te!
        </span>
      </p>
    </div>
  );
};

export default LoginForm;
