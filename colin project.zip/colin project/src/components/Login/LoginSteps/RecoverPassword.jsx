import SimpleInput from "../../Inputs/SimpleInput";
import PrimaryButton from "../../Buttons/PrimaryButton";

const RecoverPassword = ({ setStep, closeModal }) => {
  return (
    <div>
      <div className="flex justify-between items-center w-full">
        <div className="flex items-center">
          <img
            src="/images/back_icon.png"
            alt="Back Icon"
            className="mr-3 cursor-pointer"
            onClick={() => setStep(0)}
          />
          <p className="text-xs">Autentificare</p>
        </div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
        />
      </div>
      <div className="px-20 py-6" style={{ width: "26rem" }}>
        <img
          src="/images/logo_small.png"
          alt="Logo"
          className="mx-auto block"
        />
        <p className="mt-10 text-2xl font-semibold font-nunitosans">
          Reseteaza parola
        </p>
        <div className="w-full mt-4">
          <SimpleInput inputLabel="Email" />
        </div>
        <PrimaryButton text="Resetare" onClick={() => setStep(2)} />
      </div>
    </div>
  );
};

export default RecoverPassword;
