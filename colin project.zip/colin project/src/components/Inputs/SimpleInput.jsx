const SimpleInput = (props) => {
    return (
      <div>
        <p className={`font-semibold ${props.xs ? 'text-xs' : ''}`}>{props.inputLabel}</p>
        <input
          type="text"
          className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded"
          {...props}
        />
      </div>
    );
  };
  
  export default SimpleInput;
  