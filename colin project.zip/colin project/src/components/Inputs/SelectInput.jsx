const SelectInput = ({ inputLabel, options }) => {
    return (
      <div>
        <p className="font-semibold text-xs">{inputLabel}</p>
        <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded">
          {options.map((option, index) => (
            <option value={option} key={index}>
              {option}
            </option>
          ))}
        </select>
      </div>
    );
  };
  
  export default SelectInput;
  