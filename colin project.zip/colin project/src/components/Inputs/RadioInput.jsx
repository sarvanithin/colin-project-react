const RadioInput = ({ inputLabel, optOne, optTwo }) => {
    return (
      <div>
        <p className="font-semibold mt-4 text-xs">{inputLabel}</p>
        <div className="w-full mt-2 flex items-center">
          <div className="flex items-center mr-4">
            <input
              type="radio"
              value="Person"
              name="entity"
              className="mr-2 w-5 h-5"
            />
            <p className="text-xs">{optOne}</p>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              value="Company"
              name="entity"
              className="mr-2 w-5 h-5"
            />
            <p className="text-xs">{optTwo}</p>
          </div>
        </div>
      </div>
    );
  };
  
  export default RadioInput;
  