import ProfileModalAddProject from "./Modals/ProfileModalAddProject";
import ProfileModalAvatar from "./Modals/ProfileModalAvatar";
import ProfileModalContact from "./Modals/ProfileModalContact";
import ProfileModalDescription from "./Modals/ProfileModalDescription";
import ProfileModalInfo from "./Modals/ProfileModalInfo";
import ProfileModalServices from "./Modals/ProfileModalServices";
import ProfileModalWorkArea from "./Modals/ProfileModalWorkArea";

const ProfileModal = ({ closeModal, modalType }) => {
  return (
    <div>
      {modalType === "information" ? (
        <ProfileModalInfo closeModal={closeModal} />
      ) : modalType === "contact" ? (
        <ProfileModalContact closeModal={closeModal} />
      ) : modalType === 'description' ? (
        <ProfileModalDescription closeModal={closeModal} />
      ) : modalType === 'services' ? (
        <ProfileModalServices closeModal={closeModal} />
      ) : modalType === 'avatar' ? (
        <ProfileModalAvatar closeModal={closeModal} />
      ) : modalType === 'workarea' ? (
        <ProfileModalWorkArea closeModal={closeModal} />
      ) : modalType === 'addproject' && (
        <ProfileModalAddProject closeModal={closeModal} />
      )}
    </div>
  );
};

export default ProfileModal;
