const ProfileModalAvatar = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="text-2xl font-semibold font-nunitosans">Personalizeaza</p>
          <div className="w-full mt-4">
            <p className="font-semibold">Avatar</p>
            <div className="flex justify-between items-center mt-4 w-full">
              <div className="w-20 h-20 rounded border-2 border-dashed border-gray-500 rounded-full"></div>
              <div className="flex flex-col">
                <button
                  className="px-3 py-1 bg-transparent rounded text-xs"
                  style={{ border: "3px solid #000" }}
                >
                  Incarca imagine
                </button>
                <button className="px-5 py-1 bg-transparent text-xs">Sterge</button>
              </div>
            </div>
          </div>
          <button className="bg-black w-full px-3 py-2 rounded text-white mt-16 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Modifica
          </button>
          <p className="mt-4 text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalAvatar;
  