const ProfileModalInfo = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="text-2xl font-semibold font-nunitosans">Informatii</p>
          <div className="w-full mt-4">
            <p className="font-semibold">Experienta</p>
            <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded">
              <option value="5 ani">5 ani</option>
              <option value="2 years">2 years</option>
              <option value="15 years">15 years</option>
              <option value="30 years">30 years</option>
            </select>
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold">Echipa</p>
            <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded">
              <option value="1-3">1-3 meseriasi</option>
              <option value="4-10">4-10 people</option>
            </select>
          </div>
          <p className="font-semibold mt-4">Pret constatare</p>
          <div className="w-full mt-2 flex items-center">
            <div className="flex items-center mr-4">
              <input
                type="radio"
                value="Person"
                name="entity"
                className="mr-2 w-5 h-5"
              />
              <p>Nu</p>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                value="Company"
                name="entity"
                className="mr-2 w-5 h-5"
              />
              <p>Da</p>
            </div>
          </div>
          <button className="bg-black w-full px-3 py-2 rounded text-white mt-8 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Modifica
          </button>
          <p className="mt-4 text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalInfo;
  