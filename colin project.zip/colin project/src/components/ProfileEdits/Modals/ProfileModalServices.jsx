const ProfileModalServices = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="text-2xl font-semibold font-nunitosans">Servicii oferite</p>
          <div className="w-full mt-4">
            <p className="font-semibold">Servicii adaugate</p>
            <div className="flex flex-wrap justify-evenly my-4">
              <div className="bg-gray-200 rounded-full py-2 px-3 my-2 flex items-center">
                <p>painting</p>
                <img
                  src="/images/close_icon.png"
                  alt="Cross Icon"
                  className="ml-1"
                />
              </div>
              <div className="bg-gray-200 rounded-full py-2 px-3 my-2 flex items-center">
                <p>painting</p>
                <img
                  src="/images/close_icon.png"
                  alt="Cross Icon"
                  className="ml-1"
                />
              </div>
              <div className="bg-gray-200 rounded-full py-2 px-3 my-2 flex items-center">
                <p>painting</p>
                <img
                  src="/images/close_icon.png"
                  alt="Cross Icon"
                  className="ml-1"
                />
              </div>
              <div className="bg-gray-200 rounded-full py-2 px-3 my-2 flex items-center">
                <p>painting</p>
                <img
                  src="/images/close_icon.png"
                  alt="Cross Icon"
                  className="ml-1"
                />
              </div>
            </div>
            <button
              className="bg-transparent px-5 py-1 rounded mt-3"
              style={{ border: "3px solid #000" }}
            >
              Adauga serviciu
            </button>
          </div>
          <button className="bg-black w-full px-3 py-2 rounded text-white mt-8 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Modifica
          </button>
          <p className="mt-4 text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalServices;
  