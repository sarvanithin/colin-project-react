const ProfileModalWorkArea = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="mt-10 text-2xl font-semibold font-nunitosans">Zona de operare</p>
          <div className="w-full mt-4">
            <p className="font-semibold">Oras</p>
            <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded">
              <option value="Bucuresti">Bucuresti</option>
              <option value="Option 2">Option 2</option>
            </select>
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold">Raza de operare</p>
            <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded">
              <option value="25">25km</option>
              <option value="50">50km</option>
            </select>
          </div>
          <img src="/images/map_image.png" alt="Map" className="w-full mt-6" />
          <button className="bg-black w-full px-3 py-2 rounded text-white mt-8 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Modifica
          </button>
          <p className="mt-4 text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalWorkArea;
  