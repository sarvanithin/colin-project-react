const ProfileModalAddProject = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="font-semibold font-nunitosans text-xl">Adauga lucrare</p>
          <div className="w-full mt-4">
            <div className="border-2 border-gray-500 border-dashed w-full h-48 rounded flex items-center justify-center">
              <button className="px-5 py-1 bg-transparent border-2 border-solid border-black rounded text-xs">
                Incarca imagine
              </button>
            </div>
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Titlu</p>
            <input
              type="text"
              className="border border-gray-400 border-solid px-3 py-2 w-full shadow mt-2 outline-none text-xs"
              placeholder="Adauga un titlu reprezentativ"
            />
          </div>
          <div className="w-full mt-5">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-xs">Descriere</p>
              <p className="text-xs">0/250 caractere</p>
            </div>
            <textarea className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded h-32 resize-none rounded"></textarea>
          </div>
          <button className="text-xs bg-black w-full px-3 py-2 rounded text-white mt-4 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Adauga
          </button>
          <p className="text-xs mt-4 text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalAddProject;
  