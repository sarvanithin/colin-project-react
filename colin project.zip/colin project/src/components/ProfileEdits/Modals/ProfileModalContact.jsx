const ProfileModalContact = ({ closeModal }) => {
    return (
      <div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
          className="absolute top-3 right-3"
        />
        <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
          <p className="text-xl font-semibold font-nunitosans">Date de contact</p>
          <p className="font-semibold mt-4 text-xs">Entitate</p>
          <div className="w-full mt-2 flex items-center">
            <div className="flex items-center mr-4">
              <input
                type="radio"
                value="Person"
                name="entity"
                className="mr-2 w-4 h-4"
              />
              <p className="text-xs">Persoana fizica</p>
            </div>
            <div className="flex items-center">
              <input
                type="radio"
                value="Company"
                name="entity"
                className="mr-2 w-4 h-4"
              />
              <p className="text-xs">Companie</p>
            </div>
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Nume</p>
            <input
              type="text"
              className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded text-xs"
            />
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Prenume</p>
            <input
              type="password"
              className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded text-xs"
            />
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Adresa</p>
            <input
              type="password"
              className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded text-xs"
              placeholder="Strada, bloc, apartament"
            />
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Oras</p>
            <select className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded text-xs">
              <option value="Alege oras">Alege oras</option>
              <option value="Option 2">Option 2</option>
            </select>
          </div>
          <div className="w-full mt-4">
            <p className="font-semibold text-xs">Telefon</p>
            <input
              type="text"
              className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded text-xs"
              placeholder="+40754285507"
            />
          </div>
          <button className="text-xs bg-black w-full px-3 py-2 rounded text-white mt-8 mb-4 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
            Modifica
          </button>
          <p className="text-xs text-center font-semibold text-gray-500 cursor-pointer">
            Anuleaza
          </p>
        </div>
      </div>
    );
  };
  
  export default ProfileModalContact;
  