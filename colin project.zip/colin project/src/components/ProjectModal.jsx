import { useState } from "react";
import Modal from "react-modal";
import ProjectEdit from "./ProjectEdit";

const customStyles = {
  content: {
    inset: "0px",
    overflow: "hidden",
  },
};

const customStylesForEdit = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};

const ProjectModal = ({ modalIsOpen, closeModal }) => {
  const [editModalOpen, setEditModalOpen] = useState(false);

  function openEditModal() {
    setEditModalOpen(true);
  }

  function closeEditModal() {
    setEditModalOpen(false);
  }

  return (
    <Modal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      style={customStyles}
    >
      <div className="w-full h-full flex sm:flex-row flex-col">
        <div className="sm:w-9/12 w-full relative">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <img
                src="/images/cancel_icon.png"
                alt=""
                className="mr-3 cursor-pointer w-5"
                onClick={closeModal}
              />
              <img src="/images/logo_small.png" alt="" className="w-5" />
            </div>
            <div className="flex items-center">
              <img src="/images/zoom_in_icon.png" alt="" className="mr-3 w-5" />
              <img src="/images/zoom_out_icon.png" alt="" className="w-5" />
            </div>
          </div>
          <div className="flex items-center justify-center sm:mt-0 mt-2">
            <img
              src="/images/next_icon.png"
              alt=""
              className="absolute top-2/4 right-0 w-8"
            />
            <img
              src="/images/prev_icon.png"
              alt=""
              className="absolute top-2/4 left-0 w-8"
            />
            <img src="/images/geyser-image.png" alt="" className="sm:h-full h-48" />
          </div>
        </div>
        <div className="sm:w-3/12 w-full">
          <div className="bg-white flex justify-end w-full sm:mt-0 mt-4">
            <div className="flex items-center self-end mr-5 cursor-pointer">
              <img src="/images/delete_icon.png" alt="" className="w-5" />
              <p className="text-xs">Sterge</p>
            </div>
            <div className="flex items-center self-end cursor-pointer" onClick={openEditModal}>
              <img src="/images/edit_icon.png" alt="" className="w-5" />
              <p className="text-xs">Editeaza</p>
            </div>
          </div>
          <div className="w-full sm:px-12 px-4">
            <div className="flex sm:mt-20 mt-4">
              <img
                src="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt="Avatar"
                className="w-14 h-14 rounded-full"
              />
              <div className="ml-4">
                <p className="font-bold text-base">Mihai Emilian Stoica</p>
                <p className="font-bold text-sm mt-2">Zugrav</p>
                <div className="flex items-center mt-2">
                  <img
                    src="/images/location-icon.png"
                    className="mr-1 w-5"
                    alt=""
                  />
                  <p className="font-semibold text-gray-500 text-xs">
                    București, Sector 2
                  </p>
                </div>
              </div>
            </div>
            <hr className="mt-8" />
            <div className="mt-8">
              <p className="font-bold text-base">
                Titlu lucrare aici max 160 caractere.
              </p>
              <p className="font-semibold text-gray-500 mt-2 text-sm">
                Echipa noastră de tehnicieni in instalații sanitare și termice
                va pun la dispoziție următoarele servicii in care suntem
                specializați la prețuri avantajoase. max 250 caractere.
              </p>
            </div>
          </div>
        </div>
      </div>
      <Modal
        isOpen={editModalOpen}
        onRequestClose={closeEditModal}
        style={customStylesForEdit}
      >
        <ProjectEdit closeModal={closeEditModal} />
      </Modal>
    </Modal>
  );
};

export default ProjectModal;
