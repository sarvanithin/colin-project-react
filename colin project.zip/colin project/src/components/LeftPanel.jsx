import Accordion from "./Accordion";

const LeftPanel = () => {
  return (
    <div
      className="bg-white sm:px-3 px-5 sm:py-0 py-2"
      style={
        window.innerWidth < 760
          ? { width: "100%", height: "auto" }
          : { width: "22%", height: "calc(100vh - 76px)" }
      }
    >
      <div className="flex justify-between items-center my-2">
        <p className="font-semibold text-md">Caută dupa serviciu</p>
        <div className="flex items-center">
          <img src="/images/cross-icon.png" alt="Cross Icon" className="h-5" />
          <p className="text-blue-500 font-semibold cursor-pointer text-xs">
            Șterge filtre
          </p>
        </div>
      </div>
      <input
        type="text"
        className="px-2 w-full py-2 border-gray-400 border-solid border rounded my-2 outline-none text-md"
        placeholder="Montaj acoperiș, reparație acoperiș"
      />
      <div className="my-2">
        <p className="font-semibold text-md">Locație</p>
        <div className="flex items-center my-2 border border-solid border-gray-400 px-2 py-2 w-full rounded">
          <img
            src="/images/location-icon.png"
            alt="Location Icon"
            className="mr-2 h-5"
          />
          <input
            type="text"
            placeholder="București, Iași, Cluj"
            className="outline-none flex-1 text-md"
          />
        </div>
      </div>
      <div className="my-2">
        <Accordion title="Entitate">
          <div className="flex items-center">
            <div className="flex items-center mr-4">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Companie</p>
            </div>
            <div className="flex items-center mx-2">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Persoană fizică</p>
            </div>
          </div>
        </Accordion>
      </div>
      <div className="my-2">
        <Accordion title="Services">
          <div>
            <div className="flex items-center my-2">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Montaj tigla metalica</p>
            </div>
            <div className="flex items-center my-2">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Montaj tigla cu roca</p>
            </div>
            <div className="flex items-center my-2">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Montaj tigla ceramica</p>
            </div>
            <div className="flex items-center my-2">
              <input type="checkbox" className="w-4 h-4 mr-2" />
              <p className="text-xs">Montaj sistem pluvial</p>
            </div>
            <p className="text-blue-500 font-semibold cursor-pointer text-xs">
              Incarca inca 5 servicii
            </p>
          </div>
        </Accordion>
      </div>
    </div>
  );
};

export default LeftPanel;
