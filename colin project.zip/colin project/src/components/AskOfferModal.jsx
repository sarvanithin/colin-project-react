import Modal from "react-modal";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};

const AskOfferModal = ({ modalIsOpen, closeModal }) => {
  return (
    <Modal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      style={customStyles}
    >
      <img
        src="/images/close_icon.png"
        alt="Close Icon"
        onClick={closeModal}
        className="absolute top-3 right-3"
      />
      <div className="px-20 mt-5 py-5" style={{ width: "30rem" }}>
        <p className="text-2xl font-semibold font-nunitosans">
          Solicita oferta
        </p>
        <div className="w-full mt-6">
          <p className="font-semibold">Email</p>
          <input
            type="text"
            className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded"
          />
        </div>
        <div className="w-full mt-4">
          <p className="font-semibold">Telefon</p>
          <input
            type="password"
            className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded"
          />
        </div>
        <div className="w-full mt-4">
          <p className="font-semibold">Titlu</p>
          <input
            type="password"
            className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded"
          />
        </div>
        <div className="w-full mt-5">
          <div className="flex items-center justify-between">
            <p className="font-semibold">Descriere proiect</p>
            <p>0/250 caractere</p>
          </div>
          <textarea className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded h-32 resize-none rounded"></textarea>
        </div>
        <button className="px-5 py-1 bg-transparent border-2 border-solid border-black rounded">
          Incarca fisier
        </button>
        <button className="bg-black w-full px-3 py-2 rounded text-white mt-8 mb-4 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300">
          Adauga
        </button>
        <p className="mt-2 text-center font-semibold text-gray-500 cursor-pointer">
          Anuleaza
        </p>
      </div>
    </Modal>
  );
};

export default AskOfferModal;
