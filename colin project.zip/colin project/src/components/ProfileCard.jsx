import { useNavigate } from "react-router-dom";

const ProfileCard = ({ image, firstName, lastName, role, city, services }) => {
  const navigate = useNavigate();

  return (
    <div
      className="bg-white w-full flex flex-col items-center justify-center py-10 px-5 rounded cursor-pointer"
      onClick={() => navigate("/public-profile")}
    >
      <img
        src={image}
        alt={`${firstName} ${lastName}`}
        className="w-16 h-16 rounded-full"
      />
      <p className="text-lg font-semibold mt-5">
        {firstName} {lastName}
      </p>
      <p className="font-semibold text-md mt-3">{role}</p>
      <div className="flex items-center justify-center mt-3">
        <img
          src="/images/location-icon.png"
          alt="Location icon"
          className="mr-1"
        />
        <p style={{fontSize: '15px'}}>{city}</p>
      </div>
      <div className="flex mt-3 flex-wrap items-center justify-center mx-2">
        {services.map((service, index) => (
          <div
            className="bg-gray-200 rounded-full py-2 px-3 mx-2 my-2 hover:bg-gray-300 hover:font-semibold cursor-pointer"
            key={index}
          >
            <p style={{fontSize: '15px'}}>{service}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProfileCard;
