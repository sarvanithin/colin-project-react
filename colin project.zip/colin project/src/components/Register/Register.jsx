import { useState } from "react";
import StepZero from "./RegisterSteps/StepZero";
import StepOne from "./RegisterSteps/StepOne";
import StepTwo from "./RegisterSteps/StepTwo";
import StepThree from "./RegisterSteps/StepThree";

const Register = ({ closeModal, setModalCase }) => {
  const [step, setStep] = useState(0);
  return (
    <>
      {step === 0 ? (
        <StepZero closeModal={closeModal} setStep={setStep} setModalCase={setModalCase} />
      ) : step === 1 ? (
        <StepOne closeModal={closeModal} setStep={setStep} step={step} />
      ) : step === 2 ? (
        <StepTwo closeModal={closeModal} setStep={setStep} step={step} />
      ) : step === 3 && (
        <StepThree closeModal={closeModal} setStep={setStep} step={step} />
      )}
    </>
  );
};

export default Register;
