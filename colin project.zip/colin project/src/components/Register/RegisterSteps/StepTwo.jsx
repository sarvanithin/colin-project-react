import SelectInput from '../../Inputs/SelectInput'
import PrimaryButton from '../../Buttons/PrimaryButton'

const StepTwo = ({ closeModal, setStep, step }) => {
  return (
    <div>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <img
            src="/images/back_icon.png"
            alt="Back Icon"
            className="mr-3 cursor-pointer"
            onClick={() => setStep(step - 1)}
          />
          <p className="text-xs">Pasul 2 din 3</p>
        </div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
        />
      </div>
      <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
        <p className="sm:mt-5 text-xl font-semibold">Experienta</p>
        <div className="w-full mt-4">
          <SelectInput inputLabel='Profil' options={['Mester', 'Role 2']} />
        </div>
        <div className="w-full mt-4">
          <p className="font-semibold text-xs">
            Servicii sugerate in functie de profil
          </p>
          <div className="flex flex-wrap justify-center items-center mt-2">
            <div className="bg-gray-200 rounded-full py-2 px-2 my-2 mx-2 hover:bg-gray-300 font-semibold cursor-pointer">
              <p className="text-xs">Gresie si faianta</p>
            </div>
            <div className="bg-gray-200 rounded-full py-2 px-2 my-2 mx-2 hover:bg-gray-300 font-semibold cursor-pointer">
              <p className="text-xs">Reparatii instalatii</p>
            </div>
            <div className="bg-gray-200 rounded-full py-2 px-2 my-2 mx-2 hover:bg-gray-300 font-semibold cursor-pointer">
              <p className="text-xs">Zugraveli</p>
            </div>
            <div className="bg-gray-200 rounded-full py-2 px-2 my-2 mx-2 hover:bg-gray-300 font-semibold cursor-pointer">
              <p className="text-xs">Parchet</p>
            </div>
            <div className="bg-gray-200 rounded-full py-2 px-2 my-2 mx-2 hover:bg-gray-300 font-semibold cursor-pointer">
              <p className="text-xs">Instalatii</p>
            </div>
          </div>
          <button
            className="bg-transparent px-5 py-1 rounded mt-3"
            style={{ border: "3px solid #000" }}
          >
            Adauga serviciu
          </button>
        </div>
        <div className="w-full mt-5">
          <div className="flex items-center justify-between">
            <p className="font-semibold">Descriere</p>
            <p>0/250 caractere</p>
          </div>
          <textarea className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded h-32 resize-none"></textarea>
        </div>
        <PrimaryButton text='Continua' onClick={() => setStep(3)} />
        <p className=" mt-2 text-center font-semibold text-gray-500 cursor-pointer">
          Completeaza mai tarziu
        </p>
      </div>
    </div>
  );
};

export default StepTwo;
