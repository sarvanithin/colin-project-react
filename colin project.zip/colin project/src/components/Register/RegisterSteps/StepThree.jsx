import SelectInput from '../../Inputs/SelectInput'
import RadioInput from '../../Inputs/RadioInput'
import PrimaryButton from '../../Buttons/PrimaryButton'

const StepThree = ({ closeModal, setStep, step }) => {
  return (
    <div>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <img
            src="/images/back_icon.png"
            alt="Back Icon"
            className="mr-3 cursor-pointer"
            onClick={() => setStep(step - 1)}
          />
          <p className="text-xs">Pasul 3 din 3</p>
        </div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
        />
      </div>
      <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
        <p className="mt-5 text-xl font-semibold">Personalieaza profilul</p>
        <div className="w-full mt-4">
          <p className="font-semibold">Avatar</p>
          <div className="flex justify-between items-center mt-4 w-full">
            <div className="w-20 h-20 rounded border-2 border-dashed border-gray-500 rounded-full"></div>
            <div className="flex flex-col">
              <button
                className="px-3 py-1 bg-transparent rounded text-xs"
                style={{ border: "3px solid #000" }}
              >
                Incarca imagine
              </button>
              <button className="px-5 py-1 bg-transparent text-xs">Sterge</button>
            </div>
          </div>
        </div>
        <div className="w-full mt-4">
          <SelectInput inputLabel='Experienta' options={['1 an', '2 years', '15 years', '30 years']} />
        </div>
        <RadioInput inputLabel='Pret constatare' optOne='Nu' optTwo='Da' />
        <RadioInput inputLabel='Curatenie' optOne='Nu' optTwo='Da' />
        <div className="w-full mt-4">
          <SelectInput inputLabel='Echipa' options={['1-3 meseriasi', '4-10 people']} />
        </div>
        <PrimaryButton text='Finalizeaza' onClick={() => setStep(3)} />
        <p className="mt-4 text-center font-semibold text-gray-500 cursor-pointer">
          Completeaza mai tarziu
        </p>
      </div>
    </div>
  );
};

export default StepThree;
