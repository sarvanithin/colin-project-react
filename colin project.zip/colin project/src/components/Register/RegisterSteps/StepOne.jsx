import RadioInput from "../../Inputs/RadioInput";
import SelectInput from "../../Inputs/SelectInput";
import SimpleInput from "../../Inputs/SimpleInput";
import PrimaryButton from "../../Buttons/PrimaryButton";

const StepOne = ({ closeModal, setStep, step }) => {
  return (
    <div>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <img
            src="/images/back_icon.png"
            alt="Back Icon"
            className="mr-3 cursor-pointer"
            onClick={() => setStep(step - 1)}
          />
          <p className="text-xs">Pasul 1 din 3</p>
        </div>
        <img
          src="/images/close_icon.png"
          alt="Close Icon"
          onClick={closeModal}
        />
      </div>
      <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
        <p className="mt-5 text-xl font-semibold">Date de contact</p>
        <RadioInput
          inputLabel="Entitate"
          optOne="Persoana fizica"
          optTwo="Companie"
        />
        <div className="w-full mt-4">
          <p className="font-semibold text-xs">Nume</p>
          <input
            type="text"
            className="border border-gray-400 border-solid px-3 py-2 w-full my-2 outline-none rounded"
          />
        </div>
        <div className="w-full mt-4">
          <SimpleInput inputLabel="Prenume" xs />
        </div>
        <div className="w-full mt-4">
          <SimpleInput
            inputLabel="Adresa"
            xs
            placeholder="Strade, bloc, apartament"
          />
        </div>
        <div className="w-full mt-4">
          <SelectInput inputLabel="Oras" options={["Alege oras", "Option 2"]} />
        </div>
        <div className="w-full mt-4">
          <SimpleInput inputLabel="Telefon" placeholder="+40754285507" xs />
        </div>
        <PrimaryButton text="Continua" onClick={() => setStep(2)} />
      </div>
    </div>
  );
};

export default StepOne;
