import SimpleInput from "../../Inputs/SimpleInput";
import PrimaryButton from "../../Buttons/PrimaryButton";

const StepZero = ({ closeModal, setModalCase, setStep }) => {
  return (
    <div className="sm:px-20" style={window.innerWidth > 760 ? { width: "26rem" } : {width: '15rem'}}>
      <img
        src="/images/close_icon.png"
        alt="Close Icon"
        className="absolute top-2 right-2 cursor-pointer"
        onClick={closeModal}
      />
      <img src="/images/logo_small.png" alt="Logo" className="block mx-auto" />
      <p className="mt-10 text-2xl font-semibold font-nunitosans">
        Inregistrare
      </p>
      <div className="w-full mt-4">
        <SimpleInput inputLabel="Introdu adresa de email" />
      </div>
      <div className="w-full mt-4">
        <SimpleInput inputLabel="Parola" />
      </div>
      <p className="text-gray-400 mt-2">
        Folosește 8 sau mai multe caractere combinate cu litere, cifre si
        simboluri.
      </p>
      <p className="text-gray-400 mt-">
        Inregistrandu-va, sunteti de acord cu Termenii si conditiile si ati
        citit si ati luat la cunostinta Prelucrarea datelor.
      </p>
      <PrimaryButton text='Continua' onClick={() => setStep(1)} />
      <p className="mt-12 text-center">
        Ai deja cont?{" "}
        <span
          className="font-semibold underline cursor-pointer"
          onClick={() => setModalCase("login")}
        >
          Autentifica-te!
        </span>
      </p>
    </div>
  );
};

export default StepZero;
