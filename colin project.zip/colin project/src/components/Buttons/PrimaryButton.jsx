const PrimaryButton = ({ text, onClick, hFull, wNotFull }) => {
    return (
      <button
        onClick={onClick ? onClick : () => {}}
        className={`bg-black w-full px-3 py-2 rounded text-white mt-4 hover:bg-transparent border-2 border-solid border-black hover:text-black duration-300 ${hFull ? 'h-full' : ''} ${wNotFull && ''}`}
      >
        {text}
      </button>
    );
  };
  
  export default PrimaryButton;
  