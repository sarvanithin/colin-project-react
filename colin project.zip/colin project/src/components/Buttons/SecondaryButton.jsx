const SecondaryButton = ({ text, onClick }) => {
    return (
      <button
        className="bg-transparent w-full px-3 py-2 rounded mt-4 border border-solid border-black"
        onClick={onClick ? onClick : () => {}}
      >
        {text}
      </button>
    );
  };
  
  export default SecondaryButton;
  