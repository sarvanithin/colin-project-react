import LeftPanel from "../components/LeftPanel";
import ProfileCard from "../components/ProfileCard";

const HomeScreen = () => {
  return (
    <div className="sm:flex sm:overflow-hidden">
      <LeftPanel />
      <div
        className="sm:px-28 px-4 py-8 sm:overflow-y-auto flex-1"
        style={window.innerWidth > 760 ? { maxHeight: "calc(100vh - 76px)" } : {}}
      >
        <p className="font-semibold mb-5">
          453 Meșteri ideplinesc condițiile de căutare
        </p>
        <div className="grid sm:grid-cols-2 grid-cols-1 gap-8 w-full">
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
          <ProfileCard
            image="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            firstName="Mihai"
            lastName="Emilian Stoica"
            role="Zugrav"
            city="București, Sector 2"
            services={[
              "Gresie si faianta",
              "Reparatii instalatii",
              "Zugraveli",
              "Parchet",
              "Instalatii",
            ]}
          />
        </div>
        <p className="text-center mt-8 text-sm">8 din 432 meșteri</p>
        <button className="border border-solid border-gray-500 bg-white px-4 py-3 rounded block mx-auto mt-3 text-sm">
          Încarcă încă 20 de meșteri
        </button>
      </div>
    </div>
  );
};

export default HomeScreen;
