import { useState } from "react";
import AskOfferModal from "../components/AskOfferModal";
import ProjectModal from "../components/ProjectModal";
import { useNavigate } from "react-router-dom";

const PublicProfileScreen = () => {
  const [modalIsOpen, setIsOpen] = useState(false);
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [callText, setCallText] = useState("Apeleaza");
  const [cards, setCards] = useState(6);

  function openModal() {
    setIsOpen(true);
  }

  function closeModal() {
    setIsOpen(false);
  }
  function openProjectModal() {
    setProjectModalOpen(true);
  }

  function closeProjectModal() {
    setProjectModalOpen(false);
  }

  const navigate = useNavigate();

  return (
    <div className="sm:px-48 px-2 py-2 sm:py-20">
      <div className="flex cursor-pointer" onClick={() => navigate("/")}>
        <img
          src="/images/back_icon.png"
          alt="Back Icon"
          className="mr-3 h-6 w-6"
        />
        <p className="text-lg">Înapoi</p>
      </div>
      <div className="flex sm:flex-row flex-col sm:items-stretch items-center sm:justify-start bg-white w-full py-12 px-12 mt-5 rounded">
        <img
          src="https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
          alt="Avatar"
          className="w-32 h-32 rounded-full"
        />
        <div className="sm:ml-12 flex-1 flex flex-col sm:items-stretch items-center sm:mt-0 mt-4">
          <p className="font-semibold text-xl">Mihai Emilian Stoica</p>
          <p className="font-semibold mt-2">Zugrav</p>
          <div className="flex items-center mt-2">
            <img
              src="/images/location-icon.png"
              alt="Location Icon"
              className="mr-1 w-5"
            />
            <p className="text-sm">București, Sector 2</p>
          </div>
          <div className="flex sm:flex-row flex-col items-center self-end sm:mt-0 mt-3">
            <button
              className="px-12 py-2 bg-transparent flex items-center rounded sm:mr-4 sm:h-full w-full"
              style={{ border: "3px solid #000" }}
              onClick={() => setCallText("+40754285507")}
            >
              <img
                src="/images/call_icon.png"
                alt="Call Icon"
                className="mr-4"
              />
              <p className="text-sm">{callText}</p>
            </button>
            <button
              className="px-12 sm:py-2 py-3 sm:mt-0 mt-2 bg-black flex items-center rounded text-white sm:h-full w-full hover:bg-transparent border border-solid border-black hover:text-black duration-300"
              onClick={openModal}
            >
              <p className="text-sm">Solicita oferta</p>
            </button>
          </div>
        </div>
      </div>
      <div className="flex sm:flex-row flex-col justify-between mt-5">
        <div className="bg-white py-8 px-8 sm:w-7/12 w-full rounded">
          <p className="text-xl font-semibold">Informatii</p>
          <hr className="mt-2" />
          <div className="flex sm:items-center sm:flex-row flex-col sm:justify-between mt-4">
            <div className="flex items-center">
              <img
                src="/images/assignment_icon.png"
                alt="Assignment Icon"
                className="mr-3"
              />
              <div>
                <p className="font-semibold text-sm">5 ani</p>
                <p className="text-sm">Experienta</p>
              </div>
            </div>
            <div className="flex items-center sm:mt-0 mt-4">
              <img
                src="/images/groups_icon.png"
                alt="Assignment Icon"
                className="mr-3"
              />
              <div>
                <p className="font-semibold text-sm">1-3 meseriasi</p>
                <p className="text-sm">Echipa</p>
              </div>
            </div>
            <div className="flex items-center sm:mt-0 mt-4">
              <img
                src="/images/euro_icon.png"
                alt="Assignment Icon"
                className="mr-3"
              />
              <div>
                <p className="font-semibold text-sm">Da</p>
                <p className="text-sm">Pret constatare</p>
              </div>
            </div>
          </div>
          <div className="mt-10">
            <p className="text-xl font-semibold">Descriere</p>
            <hr className="mt-2" />
            <p className="text-gray-500 mt-2 text-sm">
              Echipa noastră de tehnicieni in instalații sanitare și termice va
              pun la dispoziție următoarele servicii in care suntem specializați
              la prețuri avantajoase.
            </p>
          </div>
          <div className="mt-10">
            <p className="text-xl font-semibold">Servicii oferite</p>
            <hr className="mt-2" />
            <div className="flex flex-wrap mt-2">
              <div className="bg-gray-200 rounded-full py-2 px-3 mr-3 my-2 hover:bg-gray-300 hover:font-semibold cursor-pointer">
                <p className="text-md">Gresie si faianta</p>
              </div>
              <div className="bg-gray-200 rounded-full py-2 px-3 my-2 hover:bg-gray-300 hover:font-semibold cursor-pointer">
                <p>Zugraveli</p>
              </div>
            </div>
          </div>
          <div className="mt-10">
            <p className="text-xl font-semibold">Portofoliu</p>
            <hr className="mt-2" />
            <div
              className="grid grid-cols-3 gap-3 mt-5 cursor-pointer"
              onClick={openProjectModal}
            >
              {[...Array(cards)].map((e, i) => (
                <div className="bg-gray-500 w-full sm:h-40 h-20 rounded" key={i}></div>
              ))}
            </div>
          </div>
          <button
            className="text-md bg-transparent px-5 py-2 border-solid border-gray-500 rounded block mx-auto mt-6"
            style={{ borderWidth: "3px" }}
            onClick={() => setCards(cards + 6)}
          >
            Încarcă încă 6 lucrari
          </button>
        </div>
        <div className="bg-white sm:w-4/12 w=full py-8 px-8 rounded h-max sm:mt-0 mt-6">
          <p className="font-bold text-xl">Zona de operare</p>
          <div className="flex items-center mt-4">
            <img
              src="/images/location-icon.png"
              alt="Location Icon"
              className="mr-2 w-5"
            />
            <p className="text-sm">București, Sector 2</p>
          </div>
          <img src="/images/map_image.png" alt="" className="mt-4 w-full" />
        </div>
      </div>
      <AskOfferModal closeModal={closeModal} modalIsOpen={modalIsOpen} />
      <ProjectModal
        closeModal={closeProjectModal}
        modalIsOpen={projectModalOpen}
      />
    </div>
  );
};

export default PublicProfileScreen;
